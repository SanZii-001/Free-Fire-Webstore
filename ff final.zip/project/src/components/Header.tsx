import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Flame, Diamond, Users, MessageCircle, Phone, Sparkles, Shield } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navigationItems = [
    { name: 'Home', path: '/', icon: Flame },
    { name: 'Top-Up', path: '/top-up', icon: Diamond },
    { name: 'Accounts', path: '/accounts', icon: Users },
    { name: 'Custom Request', path: '/custom-request', icon: MessageCircle },
    { name: 'Contact', path: '/contact', icon: Phone },
  ];

  return (
    <header className={`fixed top-0 w-full z-50 transition-all duration-500 ${
      scrolled 
        ? 'bg-black/95 backdrop-blur-lg shadow-2xl border-b border-red-500/20' 
        : 'bg-black/80 backdrop-blur-sm'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Enhanced Logo */}
          <Link to="/" className="flex items-center space-x-3 group">
            <div className="relative">
              <div className="bg-gradient-to-r from-red-500 via-yellow-500 to-red-600 p-3 rounded-xl shadow-lg group-hover:shadow-red-500/50 transition-all duration-300 group-hover:scale-110 border border-red-400/30">
                <Flame className="h-7 w-7 text-white animate-pulse" />
              </div>
              <div className="absolute -top-1 -right-1">
                <Sparkles className="h-4 w-4 text-yellow-400 animate-bounce" />
              </div>
              {/* Trust indicator */}
              <div className="absolute -bottom-1 -right-1">
                <div className="bg-green-500 w-3 h-3 rounded-full border border-white animate-pulse"></div>
              </div>
            </div>
            <div className="text-white">
              <div className="font-bold text-xl bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
                NS Store Nepal
              </div>
              <div className="text-xs text-gray-300 font-medium flex items-center space-x-1">
                <Shield className="h-3 w-3 text-green-400" />
                <span>Trusted • Licensed • Secure</span>
              </div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-2">
            {navigationItems.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.name}
                  to={item.path}
                  className={`relative flex items-center space-x-2 px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-300 group ${
                    isActive
                      ? 'bg-gradient-to-r from-red-500 to-red-600 text-white shadow-lg shadow-red-500/25 border border-red-400/30'
                      : 'text-gray-300 hover:bg-white/10 hover:text-white border border-transparent hover:border-white/20'
                  }`}
                >
                  <item.icon className={`h-4 w-4 transition-transform duration-300 ${
                    isActive ? 'scale-110' : 'group-hover:scale-110'
                  }`} />
                  <span>{item.name}</span>
                  {isActive && (
                    <div className="absolute inset-0 bg-gradient-to-r from-red-500 to-red-600 rounded-xl opacity-20 animate-pulse"></div>
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Trust Badge */}
          <div className="hidden lg:flex items-center space-x-2 bg-green-600/20 backdrop-blur-sm px-3 py-2 rounded-lg border border-green-500/30">
            <Shield className="h-4 w-4 text-green-400" />
            <span className="text-green-400 font-semibold text-sm">SSL Secured</span>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-300 hover:text-white p-3 rounded-xl hover:bg-white/10 transition-all duration-300 border border-transparent hover:border-white/20"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Enhanced Mobile Navigation */}
        <div className={`md:hidden transition-all duration-500 overflow-hidden ${
          isMenuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
        }`}>
          <div className="px-2 pt-2 pb-6 space-y-2 bg-gray-900/90 rounded-2xl mt-4 backdrop-blur-lg border border-gray-700/50 shadow-2xl">
            {navigationItems.map((item, index) => {
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.name}
                  to={item.path}
                  onClick={() => setIsMenuOpen(false)}
                  className={`flex items-center space-x-3 px-4 py-4 rounded-xl text-base font-semibold transition-all duration-300 transform ${
                    isActive
                      ? 'bg-gradient-to-r from-red-500 to-red-600 text-white shadow-lg scale-105 border border-red-400/30'
                      : 'text-gray-300 hover:bg-white/10 hover:text-white hover:scale-105 border border-transparent hover:border-white/20'
                  }`}
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <item.icon className="h-5 w-5" />
                  <span>{item.name}</span>
                </Link>
              );
            })}
            
            {/* Mobile Trust Badge */}
            <div className="flex items-center justify-center space-x-2 bg-green-600/20 backdrop-blur-sm px-3 py-2 rounded-lg border border-green-500/30 mt-4">
              <Shield className="h-4 w-4 text-green-400" />
              <span className="text-green-400 font-semibold text-sm">SSL Secured Store</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;