import React, { useState } from 'react';
import { X, Shield, Clock, CheckCircle, Copy, QrCode, Phone, User, MapPin, Mail } from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: {
    type: 'diamonds' | 'account';
    title: string;
    price: number;
    details: string;
    uid?: string;
  };
}

const CheckoutModal: React.FC<CheckoutModalProps> = ({ isOpen, onClose, item }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    uid: item.uid || '',
    paymentMethod: 'esewa'
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.phone) {
      alert('Please fill in all required fields');
      return;
    }
    setStep(2);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Copied to clipboard!');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">
            {step === 1 ? 'Checkout Details' : 'Payment Information'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-6 w-6 text-gray-500" />
          </button>
        </div>

        {step === 1 ? (
          /* Step 1: Customer Information */
          <form onSubmit={handleSubmit} className="p-6">
            {/* Order Summary */}
            <div className="bg-gradient-to-r from-red-50 to-yellow-50 rounded-xl p-6 mb-6 border border-red-200">
              <h3 className="font-bold text-gray-900 mb-3">Order Summary</h3>
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-700">{item.title}</span>
                <span className="font-bold text-red-600">Rs {item.price.toLocaleString()}</span>
              </div>
              <p className="text-sm text-gray-600">{item.details}</p>
            </div>

            {/* Customer Information */}
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    <User className="h-4 w-4 inline mr-1" />
                    Full Name *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    placeholder="Enter your full name"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    <Phone className="h-4 w-4 inline mr-1" />
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    placeholder="98xxxxxxxx"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  <Mail className="h-4 w-4 inline mr-1" />
                  Email Address *
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  placeholder="your.email@example.com"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  <MapPin className="h-4 w-4 inline mr-1" />
                  Address
                </label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  placeholder="City, District (Optional)"
                />
              </div>

              {item.type === 'diamonds' && (
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Free Fire UID *
                  </label>
                  <input
                    type="text"
                    name="uid"
                    value={formData.uid}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    placeholder="Enter your Free Fire UID"
                    required
                  />
                </div>
              )}

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Payment Method
                </label>
                <select
                  name="paymentMethod"
                  value={formData.paymentMethod}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                >
                  <option value="esewa">eSewa</option>
                  <option value="khalti">Khalti</option>
                  <option value="ime">IME Pay</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              className="w-full mt-8 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white py-4 px-6 rounded-xl font-bold text-lg transition-all duration-300 transform hover:scale-105"
            >
              Proceed to Payment
            </button>
          </form>
        ) : (
          /* Step 2: Payment Information */
          <div className="p-6">
            {/* Customer Details Summary */}
            <div className="bg-gray-50 rounded-xl p-4 mb-6">
              <h3 className="font-bold text-gray-900 mb-2">Customer Details</h3>
              <div className="text-sm text-gray-600 space-y-1">
                <p><strong>Name:</strong> {formData.name}</p>
                <p><strong>Phone:</strong> {formData.phone}</p>
                <p><strong>Email:</strong> {formData.email}</p>
                {formData.uid && <p><strong>UID:</strong> {formData.uid}</p>}
              </div>
            </div>

            {/* Payment Instructions */}
            <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-xl p-6 border border-purple-200">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-purple-900 mb-2">
                  {formData.paymentMethod.charAt(0).toUpperCase() + formData.paymentMethod.slice(1)} Payment
                </h3>
                <div className="text-3xl font-bold text-red-600 mb-2">
                  Rs {item.price.toLocaleString()}
                </div>
                <p className="text-purple-700">Complete your payment using the details below</p>
              </div>

              {/* Payment Details */}
              <div className="bg-white rounded-xl p-6 shadow-lg border border-purple-200">
                <div className="text-center mb-6">
                  <div className="bg-gradient-to-r from-purple-600 to-purple-700 text-white px-6 py-3 rounded-xl font-bold text-xl mb-4">
                    {formData.paymentMethod.charAt(0).toUpperCase() + formData.paymentMethod.slice(1)}
                  </div>
                  
                  {/* QR Code */}
                  <div className="mb-6">
                    <img
                      src="https://scontent.fktm21-1.fna.fbcdn.net/v/t1.15752-9/513467573_1034555741999050_8402410932850987547_n.png?_nc_cat=104&ccb=1-7&_nc_sid=0024fc&_nc_ohc=8fVvZLrZXCsQ7kNvwGElEWD&_nc_oc=AdkNMDWSGvUZum73Ksm4DL2vuCcv2HMBbnt2PxJ3-9MgNMT2ap9Z_7PaPsX9jDU12y0&_nc_ad=z-m&_nc_cid=0&_nc_zt=23&_nc_ht=scontent.fktm21-1.fna&oh=03_Q7cD2gG9z71k93yvAUKa83uvUdoNMio_IYQA10iPJBBk_b_XpA&oe=688D0CCD"
                      alt="Payment QR Code"
                      className="w-48 h-48 mx-auto rounded-xl shadow-lg border border-gray-200"
                    />
                    <p className="text-sm text-gray-600 mt-2">Scan QR code to pay</p>
                  </div>

                  {/* Payment Number */}
                  <div className="bg-gray-50 rounded-xl p-4 mb-4">
                    <p className="text-sm text-gray-600 mb-2">Pay to this number:</p>
                    <div className="flex items-center justify-center space-x-3">
                      <span className="text-3xl font-bold text-gray-900">9769222045</span>
                      <button
                        onClick={() => copyToClipboard('9769222045')}
                        className="bg-blue-500 hover:bg-blue-600 text-white p-2 rounded-lg transition-colors"
                        title="Copy number"
                      >
                        <Copy className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  {/* Reference */}
                  <div className="bg-yellow-50 rounded-xl p-4 border border-yellow-200">
                    <p className="text-sm text-yellow-800 mb-2">
                      <strong>Reference/Remarks:</strong>
                    </p>
                    <div className="flex items-center justify-center space-x-3">
                      <span className="font-mono text-lg font-bold text-yellow-900">
                        {formData.name.split(' ')[0]}-{item.type === 'diamonds' ? formData.uid : 'ACC'}-{Date.now().toString().slice(-4)}
                      </span>
                      <button
                        onClick={() => copyToClipboard(`${formData.name.split(' ')[0]}-${item.type === 'diamonds' ? formData.uid : 'ACC'}-${Date.now().toString().slice(-4)}`)}
                        className="bg-yellow-500 hover:bg-yellow-600 text-white p-2 rounded-lg transition-colors"
                        title="Copy reference"
                      >
                        <Copy className="h-4 w-4" />
                      </button>
                    </div>
                    <p className="text-xs text-yellow-700 mt-2">
                      Please include this reference in your payment
                    </p>
                  </div>
                </div>
              </div>

              {/* Instructions */}
              <div className="mt-6 space-y-4">
                <div className="bg-green-50 rounded-xl p-4 border border-green-200">
                  <div className="flex items-center space-x-2 mb-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span className="font-bold text-green-900">After Payment:</span>
                  </div>
                  <ul className="text-sm text-green-800 space-y-1">
                    <li>• Screenshot your payment confirmation</li>
                    <li>• Send it to WhatsApp: 9769222045</li>
                    <li>• {item.type === 'diamonds' ? 'Diamonds will be delivered' : 'Account details will be sent'} within 5-15 minutes</li>
                    <li>• You'll receive email confirmation</li>
                  </ul>
                </div>

                <div className="bg-blue-50 rounded-xl p-4 border border-blue-200">
                  <div className="flex items-center space-x-2 mb-2">
                    <Clock className="h-5 w-5 text-blue-600" />
                    <span className="font-bold text-blue-900">Delivery Time:</span>
                  </div>
                  <p className="text-sm text-blue-800">
                    {item.type === 'diamonds' 
                      ? 'Diamonds will be automatically added to your Free Fire account within 5-15 minutes after payment verification.'
                      : 'Account login details will be sent to your email and WhatsApp within 5-15 minutes after payment verification.'
                    }
                  </p>
                </div>
              </div>

              {/* Contact Support */}
              <div className="mt-6 text-center">
                <a
                  href="https://wa.me/9779769222045?text=Hi! I just made a payment for my order. Here's my payment screenshot."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-xl font-bold transition-all duration-300 transform hover:scale-105"
                >
                  <Phone className="h-5 w-5" />
                  <span>Send Payment Proof on WhatsApp</span>
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CheckoutModal;