import React from 'react';
import { Shield, Lock, CheckCircle, Award } from 'lucide-react';

const SecurityBanner = () => {
  return (
    <div className="bg-gradient-to-r from-green-600 via-green-700 to-green-800 text-white py-3 relative overflow-hidden">
      {/* Animated background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-transparent via-white to-transparent transform -skew-x-12 animate-pulse"></div>
      </div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center space-x-8 text-sm font-medium">
          <div className="flex items-center space-x-2">
            <Shield className="h-4 w-4" />
            <span>SSL Secured</span>
          </div>
          <div className="flex items-center space-x-2">
            <Lock className="h-4 w-4" />
            <span>Bank-Level Security</span>
          </div>
          <div className="flex items-center space-x-2">
            <CheckCircle className="h-4 w-4" />
            <span>Verified Business</span>
          </div>
          <div className="flex items-center space-x-2">
            <Award className="h-4 w-4" />
            <span>Licensed Store</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecurityBanner;