import React, { useState, useEffect } from 'react';
import { MessageCircle, Zap } from 'lucide-react';

const WhatsAppFloat = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 1000);
    return () => clearTimeout(timer);
  }, []);

  const handleWhatsAppClick = () => {
    window.open('https://wa.me/9779769222045?text=Hello! I need help with Free Fire services.', '_blank');
  };

  return (
    <div className={`fixed bottom-6 right-6 z-50 transition-all duration-1000 ${
      isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'
    }`}>
      <div className="relative group">
        {/* Pulse Animation Ring */}
        <div className="absolute inset-0 bg-green-500 rounded-full animate-ping opacity-75"></div>
        <div className="absolute inset-0 bg-green-500 rounded-full animate-pulse opacity-50"></div>
        
        {/* Main Button */}
        <button
          onClick={handleWhatsAppClick}
          className="relative bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white p-4 rounded-full shadow-2xl transition-all duration-300 hover:scale-110 group-hover:shadow-green-500/50"
          title="Chat on WhatsApp"
        >
          <MessageCircle className="h-7 w-7" />
        </button>

        {/* Tooltip */}
        <div className="absolute right-full mr-4 top-1/2 transform -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none">
          <div className="bg-black text-white px-4 py-2 rounded-xl text-sm font-semibold whitespace-nowrap shadow-xl">
            <div className="flex items-center space-x-2">
              <Zap className="h-4 w-4 text-yellow-400" />
              <span>Need Help? Chat Now!</span>
            </div>
            <div className="absolute top-1/2 left-full transform -translate-y-1/2">
              <div className="w-0 h-0 border-l-8 border-l-black border-t-4 border-t-transparent border-b-4 border-b-transparent"></div>
            </div>
          </div>
        </div>

        {/* Online Status Indicator */}
        <div className="absolute -top-1 -right-1">
          <div className="bg-green-400 w-4 h-4 rounded-full border-2 border-white animate-bounce">
            <div className="w-2 h-2 bg-white rounded-full mx-auto mt-0.5"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WhatsAppFloat;