import React from 'react';
import { Shield, Award, Clock, Users, CheckCircle, Star, Zap, Heart } from 'lucide-react';

const TrustBadges = () => {
  const badges = [
    {
      icon: Shield,
      title: 'SSL Secured',
      subtitle: 'Bank-level encryption',
      color: 'from-green-500 to-green-600',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200'
    },
    {
      icon: Award,
      title: 'Verified Business',
      subtitle: 'Licensed & Registered',
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200'
    },
    {
      icon: Users,
      title: '10,000+ Customers',
      subtitle: 'Trusted nationwide',
      color: 'from-purple-500 to-purple-600',
      bgColor: 'bg-purple-50',
      borderColor: 'border-purple-200'
    },
    {
      icon: Clock,
      title: '24/7 Support',
      subtitle: 'Always available',
      color: 'from-orange-500 to-orange-600',
      bgColor: 'bg-orange-50',
      borderColor: 'border-orange-200'
    }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {badges.map((badge, index) => (
        <div
          key={index}
          className={`${badge.bgColor} ${badge.borderColor} border-2 rounded-xl p-4 text-center hover:shadow-lg transition-all duration-300 hover:-translate-y-1`}
        >
          <div className={`bg-gradient-to-r ${badge.color} w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3 shadow-lg`}>
            <badge.icon className="h-6 w-6 text-white" />
          </div>
          <div className="font-bold text-gray-900 text-sm">{badge.title}</div>
          <div className="text-xs text-gray-600 mt-1">{badge.subtitle}</div>
        </div>
      ))}
    </div>
  );
};

export default TrustBadges;