import React from 'react';
import { Link } from 'react-router-dom';
import { Flame, Phone, Mail, MapPin, Shield, Clock, Star, Zap, Heart, Instagram, Code } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gradient-to-br from-black via-gray-900 to-black text-white relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-20 h-20 bg-red-500 rounded-full animate-pulse"></div>
        <div className="absolute top-32 right-20 w-16 h-16 bg-yellow-500 rounded-full animate-bounce"></div>
        <div className="absolute bottom-20 left-1/4 w-12 h-12 bg-blue-500 rounded-full animate-ping"></div>
        <div className="absolute bottom-40 right-1/3 w-8 h-8 bg-green-500 rounded-full animate-pulse"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Company Info */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-3 mb-6 group">
              <div className="relative">
                <div className="bg-gradient-to-r from-red-500 via-yellow-500 to-red-600 p-3 rounded-xl shadow-lg group-hover:shadow-red-500/50 transition-all duration-300 group-hover:scale-110">
                  <Flame className="h-8 w-8 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 animate-bounce">
                  <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                </div>
              </div>
              <div>
                <div className="font-bold text-2xl bg-gradient-to-r from-white via-gray-100 to-gray-300 bg-clip-text text-transparent">
                  NS Store Nepal
                </div>
                <div className="text-sm text-gray-300 font-medium">Nepal's Most Trusted Free Fire Store</div>
              </div>
            </div>
            
            <p className="text-gray-300 mb-6 max-w-md leading-relaxed">
              We provide instant Free Fire diamond top-ups and verified accounts with secure payment options. 
              Trusted by thousands of gamers across Nepal with 24/7 support and guaranteed delivery.
            </p>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="flex items-center space-x-3 p-3 bg-green-500/10 rounded-xl border border-green-500/20">
                <Shield className="h-5 w-5 text-green-400" />
                <div>
                  <div className="font-semibold text-green-400">100% Secure</div>
                  <div className="text-xs text-gray-400">Encrypted Payments</div>
                </div>
              </div>
              <div className="flex items-center space-x-3 p-3 bg-blue-500/10 rounded-xl border border-blue-500/20">
                <Zap className="h-5 w-5 text-blue-400" />
                <div>
                  <div className="font-semibold text-blue-400">5-15 Min Delivery</div>
                  <div className="text-xs text-gray-400">Lightning Fast</div>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-2 text-yellow-400">
              <Star className="h-5 w-5 fill-current" />
              <Star className="h-5 w-5 fill-current" />
              <Star className="h-5 w-5 fill-current" />
              <Star className="h-5 w-5 fill-current" />
              <Star className="h-5 w-5 fill-current" />
              <span className="text-white font-semibold ml-2">4.9/5 Rating</span>
              <span className="text-gray-400">• 1000+ Reviews</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-bold text-xl mb-6 bg-gradient-to-r from-red-400 to-yellow-400 bg-clip-text text-transparent">
              Quick Links
            </h3>
            <ul className="space-y-3">
              {[
                { name: 'Diamond Top-Up', path: '/top-up' },
                { name: 'Buy Accounts', path: '/accounts' },
                { name: 'Custom Request', path: '/custom-request' },
                { name: 'Reviews', path: '/feedback' },
                { name: 'Contact Us', path: '/contact' }
              ].map((link, index) => (
                <li key={link.name}>
                  <Link 
                    to={link.path} 
                    className="text-gray-300 hover:text-white transition-all duration-300 hover:translate-x-2 inline-block group"
                  >
                    <span className="border-b border-transparent group-hover:border-red-400 transition-all duration-300">
                      {link.name}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-bold text-xl mb-6 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Contact Us
            </h3>
            <ul className="space-y-4">
              <li className="flex items-center space-x-3 group">
                <div className="bg-green-500/20 p-2 rounded-lg group-hover:bg-green-500/30 transition-all duration-300">
                  <Phone className="h-4 w-4 text-green-400" />
                </div>
                <div>
                  <div className="text-white font-semibold">+977 9769222045</div>
                  <div className="text-xs text-gray-400">24/7 Available</div>
                </div>
              </li>
              <li className="flex items-center space-x-3 group">
                <div className="bg-blue-500/20 p-2 rounded-lg group-hover:bg-blue-500/30 transition-all duration-300">
                  <Mail className="h-4 w-4 text-blue-400" />
                </div>
                <div>
                  <div className="text-white font-semibold">support@nsstorenepal.com</div>
                  <div className="text-xs text-gray-400">Quick Response</div>
                </div>
              </li>
              <li className="flex items-center space-x-3 group">
                <div className="bg-red-500/20 p-2 rounded-lg group-hover:bg-red-500/30 transition-all duration-300">
                  <MapPin className="h-4 w-4 text-red-400" />
                </div>
                <div>
                  <div className="text-white font-semibold">Kathmandu, Nepal</div>
                  <div className="text-xs text-gray-400">Digital Store</div>
                </div>
              </li>
            </ul>
          </div>
        </div>

        {/* Payment Methods */}
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col lg:flex-row justify-between items-center space-y-6 lg:space-y-0">
            <div>
              <h4 className="font-bold text-lg mb-4 text-center lg:text-left">Accepted Payment Methods</h4>
              <div className="flex flex-wrap justify-center lg:justify-start gap-4">
                <div className="bg-gradient-to-r from-purple-600 to-purple-700 px-6 py-3 rounded-xl font-bold shadow-lg hover:shadow-purple-500/25 transition-all duration-300 hover:scale-105">
                  eSewa
                </div>
                <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-3 rounded-xl font-bold shadow-lg hover:shadow-blue-500/25 transition-all duration-300 hover:scale-105">
                  Khalti
                </div>
                <div className="bg-gradient-to-r from-green-600 to-green-700 px-6 py-3 rounded-xl font-bold shadow-lg hover:shadow-green-500/25 transition-all duration-300 hover:scale-105">
                  IME Pay
                </div>
              </div>
            </div>
            
            <div className="text-center lg:text-right">
              <div className="flex items-center justify-center lg:justify-end space-x-2 mb-2">
                <Heart className="h-4 w-4 text-red-500 animate-pulse" />
                <p className="text-gray-400 text-sm">
                  © 2024 NS Store Nepal. All rights reserved.
                </p>
              </div>
              <p className="text-gray-500 text-xs mb-3">
                Safe, Secure & Instant Gaming Store
              </p>
              
              {/* Developer Credits */}
              <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
                <div className="flex items-center justify-center lg:justify-end space-x-2 mb-2">
                  <Code className="h-4 w-4 text-blue-400" />
                  <span className="text-blue-400 font-semibold text-sm">Developed by</span>
                </div>
                
                <div className="space-y-2 text-xs">
                  <div className="flex items-center justify-center lg:justify-end space-x-2">
                    <span className="text-white font-semibold">Nilkantha Nepal</span>
                    <span className="text-gray-400">(Owner + Developer)</span>
                  </div>
                  <div className="flex items-center justify-center lg:justify-end space-x-3">
                    <div className="flex items-center space-x-1">
                      <Instagram className="h-3 w-3 text-pink-400" />
                      <span className="text-pink-400">@neeel001</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Phone className="h-3 w-3 text-green-400" />
                      <span className="text-green-400">9769222045</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-center lg:justify-end space-x-2 pt-1 border-t border-gray-700">
                    <span className="text-white font-semibold">Saksham Subedi</span>
                    <span className="text-gray-400">(Owner)</span>
                  </div>
                  <div className="flex items-center justify-center lg:justify-end space-x-1">
                    <Instagram className="h-3 w-3 text-pink-400" />
                    <span className="text-pink-400">@sakshyam_subedi18</span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center justify-center lg:justify-end space-x-4 mt-3">
                <div className="flex items-center space-x-1 text-xs text-green-400">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  <span>Online Now</span>
                </div>
                <div className="text-xs text-gray-400">
                  1000+ Happy Customers
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;