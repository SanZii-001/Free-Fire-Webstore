import React, { useState, useEffect } from 'react';
import { Star, Quote, ChevronLeft, ChevronRight } from 'lucide-react';

const TestimonialCarousel = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const testimonials = [
    {
      name: 'Rohan Sharma',
      location: 'Kathmandu',
      rating: 5,
      comment: 'Absolutely amazing service! Got my diamonds in just 3 minutes. The payment process was smooth and secure. Highly recommend FF Store Nepal to all Free Fire players!',
      avatar: 'R',
      verified: true,
      purchase: '2180 Diamonds'
    },
    {
      name: 'Sita Poudel',
      location: 'Pokhara',
      rating: 5,
      comment: 'Bought a Heroic account and it was exactly as described. All skins were there, account was clean, and customer support was excellent. Will definitely buy again!',
      avatar: 'S',
      verified: true,
      purchase: 'Heroic Account'
    },
    {
      name: 'Arun Thapa',
      location: 'Chitwan',
      rating: 5,
      comment: 'Best prices in Nepal! Customer service responds quickly on WhatsApp. I\'ve made multiple purchases and never had any issues. Trustworthy and reliable!',
      avatar: 'A',
      verified: true,
      purchase: '5600 Diamonds'
    },
    {
      name: 'Maya Gurung',
      location: 'Lalitpur',
      rating: 5,
      comment: 'Professional service with instant delivery. The eSewa payment was seamless and I received my diamonds immediately. Great experience overall!',
      avatar: 'M',
      verified: true,
      purchase: '1090 Diamonds'
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <div className="relative bg-white rounded-2xl shadow-2xl p-8 border border-gray-100">
      <div className="absolute top-6 left-6">
        <Quote className="h-8 w-8 text-red-200" />
      </div>
      
      <div className="relative overflow-hidden">
        <div 
          className="flex transition-transform duration-500 ease-in-out"
          style={{ transform: `translateX(-${currentIndex * 100}%)` }}
        >
          {testimonials.map((testimonial, index) => (
            <div key={index} className="w-full flex-shrink-0 px-4">
              <div className="text-center">
                <div className="flex items-center justify-center space-x-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                
                <p className="text-gray-700 text-lg italic leading-relaxed mb-6 min-h-[120px]">
                  "{testimonial.comment}"
                </p>
                
                <div className="flex items-center justify-center space-x-4">
                  <div className="bg-gradient-to-r from-red-500 to-yellow-500 w-14 h-14 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg">
                    {testimonial.avatar}
                  </div>
                  <div className="text-left">
                    <div className="flex items-center space-x-2">
                      <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                      {testimonial.verified && (
                        <div className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-bold">
                          ✓ Verified
                        </div>
                      )}
                    </div>
                    <p className="text-gray-600 text-sm">{testimonial.location}</p>
                    <p className="text-red-600 text-sm font-medium">Purchased: {testimonial.purchase}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Navigation */}
      <div className="flex items-center justify-between mt-6">
        <button
          onClick={prevTestimonial}
          className="bg-gray-100 hover:bg-gray-200 p-2 rounded-full transition-colors"
        >
          <ChevronLeft className="h-5 w-5 text-gray-600" />
        </button>
        
        <div className="flex space-x-2">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentIndex ? 'bg-red-500 scale-125' : 'bg-gray-300 hover:bg-gray-400'
              }`}
            />
          ))}
        </div>
        
        <button
          onClick={nextTestimonial}
          className="bg-gray-100 hover:bg-gray-200 p-2 rounded-full transition-colors"
        >
          <ChevronRight className="h-5 w-5 text-gray-600" />
        </button>
      </div>
    </div>
  );
};

export default TestimonialCarousel;