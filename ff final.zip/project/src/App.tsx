import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import WhatsAppFloat from './components/WhatsAppFloat';
import HomePage from './pages/HomePage';
import TopUpPage from './pages/TopUpPage';
import CustomRequestPage from './pages/CustomRequestPage';
import AccountShopPage from './pages/AccountShopPage';
import AccountDetailPage from './pages/AccountDetailPage';
import FeedbackPage from './pages/FeedbackPage';
import ContactPage from './pages/ContactPage';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main className="pt-20">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/top-up" element={<TopUpPage />} />
            <Route path="/custom-request" element={<CustomRequestPage />} />
            <Route path="/accounts" element={<AccountShopPage />} />
            <Route path="/account/:id" element={<AccountDetailPage />} />
            <Route path="/feedback" element={<FeedbackPage />} />
            <Route path="/contact" element={<ContactPage />} />
          </Routes>
        </main>
        <Footer />
        <WhatsAppFloat />
      </div>
    </Router>
  );
}

export default App;