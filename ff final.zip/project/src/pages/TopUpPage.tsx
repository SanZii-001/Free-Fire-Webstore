import React, { useState } from 'react';
import { Diamond, Shield, Clock, CheckCircle, MessageCircle, Star, Zap } from 'lucide-react';
import CheckoutModal from '../components/CheckoutModal';

const TopUpPage = () => {
  const [selectedPackage, setSelectedPackage] = useState('');
  const [uid, setUid] = useState('');
  const [addOns, setAddOns] = useState({
    levelUpPass: false,
    weeklyVip: false,
    monthlyVip: false,
    unipinVoucher: false,
  });
  const [showCheckout, setShowCheckout] = useState(false);

  const packages = [
    { id: '115', diamonds: 115, price: 95, popular: false },
    { id: '230', diamonds: 230, price: 190, popular: false },
    { id: '355', diamonds: 355, price: 295, popular: false },
    { id: '480', diamonds: 480, price: 400, popular: true },
    { id: '610', diamonds: 610, price: 510, popular: false },
    { id: '725', diamonds: 725, price: 595, popular: false },
    { id: '850', diamonds: 850, price: 700, popular: false },
    { id: '1090', diamonds: 1090, price: 920, popular: true },
    { id: '1240', diamonds: 1240, price: 1020, popular: false },
    { id: '1480', diamonds: 1480, price: 1250, popular: false },
    { id: '1595', diamonds: 1595, price: 1345, popular: false },
    { id: '1740', diamonds: 1740, price: 1450, popular: false },
    { id: '1965', diamonds: 1965, price: 1615, popular: false },
    { id: '2090', diamonds: 2090, price: 1820, popular: true },
    { id: '2530', diamonds: 2530, price: 2050, popular: false },
    { id: '5600', diamonds: 5600, price: 4100, popular: true, bestValue: true },
  ];

  const addOnPrices = {
    levelUpPass: 200,
    weeklyVip: 200,
    monthlyVip: 950,
    unipinVoucher: 2250,
  };

  const addOnLabels = {
    levelUpPass: 'Level Up Pass',
    weeklyVip: 'Weekly VIP',
    monthlyVip: 'Monthly VIP',
    unipinVoucher: 'UniPin Voucher',
  };

  const calculateTotal = () => {
    const selectedPkg = packages.find(pkg => pkg.id === selectedPackage);
    const packagePrice = selectedPkg ? selectedPkg.price : 0;
    const addOnTotal = Object.entries(addOns).reduce((total, [key, value]) => {
      return total + (value ? addOnPrices[key as keyof typeof addOnPrices] : 0);
    }, 0);
    return packagePrice + addOnTotal;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!uid || !selectedPackage) {
      alert('Please fill in all required fields');
      return;
    }
    
    const selectedPkg = packages.find(pkg => pkg.id === selectedPackage);
    const addOnsList = Object.entries(addOns)
      .filter(([_, value]) => value)
      .map(([key, _]) => addOnLabels[key as keyof typeof addOnLabels])
      .join(', ');
    
    setShowCheckout(true);
  };

  const handleCustomRequest = () => {
    window.open('https://wa.me/9779769222045?text=Hi! I need a custom diamond package. My UID is: [Your UID]. I want [Number] diamonds. Please provide pricing.', '_blank');
  };

  const getCheckoutItem = () => {
    const selectedPkg = packages.find(pkg => pkg.id === selectedPackage);
    const addOnsList = Object.entries(addOns)
      .filter(([_, value]) => value)
      .map(([key, _]) => addOnLabels[key as keyof typeof addOnLabels])
      .join(', ');
    
    return {
      type: 'diamonds' as const,
      title: `${selectedPkg?.diamonds} Diamonds${addOnsList ? ` + ${addOnsList}` : ''}`,
      price: calculateTotal(),
      details: `Free Fire diamond top-up for UID: ${uid}`,
      uid: uid
    };
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center space-x-3 bg-gradient-to-r from-red-500 to-yellow-500 text-white px-6 py-3 rounded-full mb-4">
            <Diamond className="h-6 w-6" />
            <span className="font-bold text-lg">Free Fire Diamond Top-Up</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">
            Instant Diamond Delivery
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Get your Free Fire diamonds delivered instantly with secure Nepali payment methods
          </p>
        </div>

        {/* Trust Indicators */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-xl p-4 shadow-lg text-center border border-gray-100">
            <Shield className="h-8 w-8 text-green-500 mx-auto mb-2" />
            <div className="font-semibold text-gray-900 text-sm">100% Secure</div>
            <div className="text-xs text-gray-600">Encrypted Payments</div>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-lg text-center border border-gray-100">
            <Zap className="h-8 w-8 text-blue-500 mx-auto mb-2" />
            <div className="font-semibold text-gray-900 text-sm">5-15 Minutes</div>
            <div className="text-xs text-gray-600">Fast Delivery</div>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-lg text-center border border-gray-100">
            <Star className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
            <div className="font-semibold text-gray-900 text-sm">4.9/5 Rating</div>
            <div className="text-xs text-gray-600">1000+ Reviews</div>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-lg text-center border border-gray-100">
            <CheckCircle className="h-8 w-8 text-red-500 mx-auto mb-2" />
            <div className="font-semibold text-gray-900 text-sm">Guaranteed</div>
            <div className="text-xs text-gray-600">Money Back</div>
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
          {/* Main Form */}
          <div className="xl:col-span-3">
            <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-xl p-6 md:p-8 border border-gray-100">
              {/* UID Input */}
              <div className="mb-8">
                <label htmlFor="uid" className="block text-lg font-bold text-gray-900 mb-3">
                  <span className="flex items-center space-x-2">
                    <Diamond className="h-5 w-5 text-red-500" />
                    <span>Free Fire UID</span>
                    <span className="text-red-500">*</span>
                  </span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    id="uid"
                    value={uid}
                    onChange={(e) => setUid(e.target.value)}
                    placeholder="Enter your Free Fire UID (e.g., 123456789)"
                    className="w-full px-4 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500 text-lg font-medium transition-all"
                    required
                  />
                  <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
                    <Shield className="h-5 w-5 text-green-500" />
                  </div>
                </div>
                <div className="mt-2 p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-700 font-medium">
                    💡 Find your UID: Open Free Fire → Profile → Basic Info → Copy UID
                  </p>
                </div>
              </div>

              {/* Diamond Packages */}
              <div className="mb-8">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-bold text-gray-900 flex items-center space-x-2">
                    <Diamond className="h-5 w-5 text-blue-500" />
                    <span>Select Diamond Package</span>
                    <span className="text-red-500">*</span>
                  </h3>
                  <button
                    type="button"
                    onClick={handleCustomRequest}
                    className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white px-4 py-2 rounded-lg font-semibold text-sm transition-all duration-300 transform hover:scale-105 flex items-center space-x-2"
                  >
                    <MessageCircle className="h-4 w-4" />
                    <span>Custom Amount</span>
                  </button>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                  {packages.map((pkg) => (
                    <div
                      key={pkg.id}
                      className={`relative border-2 rounded-xl p-4 cursor-pointer transition-all duration-300 hover:shadow-lg ${
                        selectedPackage === pkg.id
                          ? 'border-red-500 bg-red-50 shadow-lg transform scale-105'
                          : 'border-gray-200 hover:border-gray-300 bg-white'
                      }`}
                      onClick={() => setSelectedPackage(pkg.id)}
                    >
                      {pkg.bestValue && (
                        <div className="absolute -top-2 left-1/2 transform -translate-x-1/2">
                          <span className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-black px-3 py-1 rounded-full text-xs font-bold">
                            BEST VALUE
                          </span>
                        </div>
                      )}
                      {pkg.popular && !pkg.bestValue && (
                        <div className="absolute -top-2 left-1/2 transform -translate-x-1/2">
                          <span className="bg-gradient-to-r from-green-400 to-green-500 text-white px-3 py-1 rounded-full text-xs font-bold">
                            POPULAR
                          </span>
                        </div>
                      )}
                      
                      <div className="text-center">
                        <div className="flex items-center justify-center space-x-1 mb-2">
                          <Diamond className="h-5 w-5 text-blue-500" />
                          <span className="font-bold text-lg text-gray-900">{pkg.diamonds}</span>
                        </div>
                        <div className="font-bold text-xl text-red-600">Rs {pkg.price}</div>
                        <div className="text-xs text-gray-500 mt-1">
                          Rs {(pkg.price / pkg.diamonds).toFixed(2)}/diamond
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Add-ons */}
              <div className="mb-8">
                <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center space-x-2">
                  <Star className="h-5 w-5 text-yellow-500" />
                  <span>Add-ons (Optional)</span>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.entries(addOnPrices).map(([key, price]) => (
                    <label key={key} className="flex items-center justify-between p-4 border-2 border-gray-200 rounded-xl cursor-pointer hover:bg-gray-50 hover:border-gray-300 transition-all">
                      <div className="flex items-center space-x-3">
                        <input
                          type="checkbox"
                          checked={addOns[key as keyof typeof addOns]}
                          onChange={(e) => setAddOns(prev => ({ ...prev, [key]: e.target.checked }))}
                          className="h-5 w-5 text-red-600 rounded border-2 border-gray-300 focus:ring-red-500"
                        />
                        <div>
                          <span className="font-semibold text-gray-900">
                            {addOnLabels[key as keyof typeof addOnLabels]}
                          </span>
                          {key === 'unipinVoucher' && (
                            <div className="text-xs text-purple-600 font-medium">Premium Voucher</div>
                          )}
                        </div>
                      </div>
                      <span className="font-bold text-red-600">Rs {price}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={!uid || !selectedPackage}
                className="w-full bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 disabled:from-gray-400 disabled:to-gray-500 text-white py-5 px-8 rounded-xl font-bold text-xl transition-all duration-300 transform hover:scale-105 disabled:transform-none shadow-lg"
              >
                {calculateTotal() > 0 ? `Proceed to Checkout - Rs ${calculateTotal()}` : 'Select Package to Continue'}
              </button>
              
              {selectedPackage && (
                <div className="mt-4 text-center">
                  <p className="text-sm text-gray-600">
                    💎 You'll receive <span className="font-bold text-red-600">{packages.find(p => p.id === selectedPackage)?.diamonds} diamonds</span> in your Free Fire account within 5-15 minutes
                  </p>
                </div>
              )}
            </form>
          </div>

          {/* Order Summary Sidebar */}
          <div className="xl:col-span-1">
            <div className="bg-white rounded-2xl shadow-xl p-6 sticky top-24 border border-gray-100">
              <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center space-x-2">
                <CheckCircle className="h-6 w-6 text-green-500" />
                <span>Order Summary</span>
              </h3>
              
              {selectedPackage ? (
                <div className="space-y-4 mb-6">
                  {(() => {
                    const pkg = packages.find(p => p.id === selectedPackage);
                    return pkg ? (
                      <div className="flex justify-between items-center p-4 bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl border border-blue-200">
                        <div className="flex items-center space-x-2">
                          <Diamond className="h-5 w-5 text-blue-500" />
                          <div>
                            <div className="font-bold text-gray-900">{pkg.diamonds} Diamonds</div>
                            <div className="text-xs text-gray-600">Main Package</div>
                          </div>
                        </div>
                        <div className="font-bold text-blue-600">Rs {pkg.price}</div>
                      </div>
                    ) : null;
                  })()}
                  
                  {Object.entries(addOns).map(([key, value]) => (
                    value ? (
                      <div key={key} className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                        <span className="font-medium text-gray-900">
                          {addOnLabels[key as keyof typeof addOnLabels]}
                        </span>
                        <span className="font-bold text-yellow-600">Rs {addOnPrices[key as keyof typeof addOnPrices]}</span>
                      </div>
                    ) : null
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Diamond className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">Select a diamond package to see your order summary</p>
                </div>
              )}
              
              {selectedPackage && (
                <>
                  <div className="border-t-2 border-gray-200 pt-4 mb-6">
                    <div className="flex justify-between items-center">
                      <span className="text-lg font-bold text-gray-900">Total Amount:</span>
                      <span className="text-2xl font-bold text-red-600">Rs {calculateTotal()}</span>
                    </div>
                  </div>
                </>
              )}
              
              <div className="text-center space-y-3">
                <div className="flex items-center justify-center space-x-2 text-green-600">
                  <Clock className="h-5 w-5" />
                  <span className="font-bold">5-15 Minutes Delivery</span>
                </div>
                <div className="flex items-center justify-center space-x-2 text-blue-600">
                  <Shield className="h-5 w-5" />
                  <span className="font-medium">100% Secure Payment</span>
                </div>
                <div className="flex items-center justify-center space-x-2 text-red-600">
                  <Star className="h-5 w-5" />
                  <span className="font-medium">Trusted by 1000+ Gamers</span>
                </div>
              </div>

              {/* Custom Request CTA */}
              <div className="mt-6 p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-200">
                <h4 className="font-bold text-purple-900 mb-2">Need Custom Amount?</h4>
                <p className="text-sm text-purple-700 mb-3">
                  Want a specific number of diamonds? Get personalized pricing!
                </p>
                <button
                  onClick={handleCustomRequest}
                  className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white py-2 px-4 rounded-lg font-semibold text-sm transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2"
                >
                  <MessageCircle className="h-4 w-4" />
                  <span>Request Custom Quote</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Trust Section */}
        <div className="mt-12 bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
          <div className="text-center mb-6">
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Why Choose NS Store Nepal?</h3>
            <p className="text-gray-600">Trusted by thousands of Free Fire players across Nepal</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                <Shield className="h-8 w-8 text-green-600" />
              </div>
              <h4 className="font-bold text-gray-900 mb-1">100% Secure</h4>
              <p className="text-sm text-gray-600">Encrypted payments & data protection</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                <Zap className="h-8 w-8 text-blue-600" />
              </div>
              <h4 className="font-bold text-gray-900 mb-1">Lightning Fast</h4>
              <p className="text-sm text-gray-600">Diamonds delivered in 5-15 minutes</p>
            </div>
            <div className="text-center">
              <div className="bg-yellow-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                <Star className="h-8 w-8 text-yellow-600" />
              </div>
              <h4 className="font-bold text-gray-900 mb-1">Top Rated</h4>
              <p className="text-sm text-gray-600">4.9/5 stars from 1000+ customers</p>
            </div>
            <div className="text-center">
              <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                <CheckCircle className="h-8 w-8 text-red-600" />
              </div>
              <h4 className="font-bold text-gray-900 mb-1">Guaranteed</h4>
              <p className="text-sm text-gray-600">Money back if not delivered</p>
            </div>
          </div>
        </div>
      </div>

      {/* Checkout Modal */}
      {showCheckout && (
        <CheckoutModal
          isOpen={showCheckout}
          onClose={() => setShowCheckout(false)}
          item={getCheckoutItem()}
        />
      )}
    </div>
  );
};

export default TopUpPage;