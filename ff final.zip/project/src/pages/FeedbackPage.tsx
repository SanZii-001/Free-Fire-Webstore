import React, { useState } from 'react';
import { Star, MessageCircle, ThumbsUp, Send } from 'lucide-react';

const FeedbackPage = () => {
  const [newReview, setNewReview] = useState({
    name: '',
    rating: 5,
    comment: '',
    service: 'top-up'
  });

  const [reviews] = useState([
    {
      id: 1,
      name: 'Rohan Sharma',
      rating: 5,
      comment: 'Super fast delivery! Got my diamonds in just 5 minutes. Will definitely use again.',
      service: 'Diamond Top-Up',
      date: '2024-01-15',
      location: 'Kathmandu',
      verified: true
    },
    {
      id: 2,
      name: 'Sita Poudel',
      rating: 5,
      comment: 'Bought a Diamond tier account and it was exactly as described. All skins were there and the account was in perfect condition. Highly recommended!',
      service: 'Account Purchase',
      date: '2024-01-14',
      location: 'Pokhara',
      verified: true
    },
    {
      id: 3,
      name: 'Arun Thapa',
      rating: 5,
      comment: 'Best prices in Nepal! Customer service is excellent and they respond quickly on WhatsApp.',
      service: 'Custom Request',
      date: '2024-01-13',
      location: 'Chitwan',
      verified: true
    },
    {
      id: 4,
      name: 'Maya Gurung',
      rating: 4,
      comment: 'Good service overall. Payment through eSewa was smooth. Only minor delay in delivery but customer support kept me updated.',
      service: 'Diamond Top-Up',
      date: '2024-01-12',
      location: 'Lalitpur',
      verified: true
    },
    {
      id: 5,
      name: 'Deepak Rai',
      rating: 5,
      comment: 'Amazing! Got 5000 diamonds with bonus at a great price. The whole process was transparent and trustworthy.',
      service: 'Bulk Purchase',
      date: '2024-01-11',
      location: 'Biratnagar',
      verified: true
    },
    {
      id: 6,
      name: 'Priya Adhikari',
      rating: 5,
      comment: 'Bought an Elite account for my brother. He loves it! All the skins and items were exactly as promised.',
      service: 'Account Purchase',
      date: '2024-01-10',
      location: 'Butwal',
      verified: true
    }
  ]);

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReview.name || !newReview.comment) {
      alert('Please fill in all required fields');
      return;
    }
    
    // In a real app, this would be sent to a backend
    alert('Thank you for your review! It will be published after verification.');
    setNewReview({ name: '', rating: 5, comment: '', service: 'top-up' });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewReview(prev => ({
      ...prev,
      [name]: name === 'rating' ? parseInt(value) : value
    }));
  };

  const averageRating = reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length;
  const ratingDistribution = [5, 4, 3, 2, 1].map(rating => ({
    rating,
    count: reviews.filter(review => review.rating === rating).length,
    percentage: (reviews.filter(review => review.rating === rating).length / reviews.length) * 100
  }));

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Customer Reviews & Feedback
          </h1>
          <p className="text-xl text-gray-600">
            See what our customers say about FF Store Nepal
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Reviews List */}
          <div className="lg:col-span-2">
            {/* Overall Rating Summary */}
            <div className="bg-white rounded-xl shadow-xl p-8 mb-8">
              <div className="flex flex-col md:flex-row items-center justify-between">
                <div className="text-center md:text-left mb-6 md:mb-0">
                  <div className="text-5xl font-bold text-red-600">{averageRating.toFixed(1)}</div>
                  <div className="flex items-center justify-center md:justify-start space-x-1 my-2">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-6 w-6 ${
                          i < Math.floor(averageRating) ? 'text-yellow-400 fill-current' : 'text-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                  <div className="text-gray-600">Based on {reviews.length} reviews</div>
                </div>
                
                <div className="space-y-2">
                  {ratingDistribution.map(({ rating, count, percentage }) => (
                    <div key={rating} className="flex items-center space-x-2">
                      <span className="text-sm font-medium">{rating}</span>
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-yellow-400 h-2 rounded-full"
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                      <span className="text-sm text-gray-600">({count})</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Individual Reviews */}
            <div className="space-y-6">
              {reviews.map((review) => (
                <div key={review.id} className="bg-white rounded-xl shadow-lg p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="bg-gradient-to-r from-red-500 to-yellow-500 w-12 h-12 rounded-full flex items-center justify-center">
                        <span className="text-white font-bold text-lg">
                          {review.name.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <h3 className="font-semibold text-gray-900">{review.name}</h3>
                          {review.verified && (
                            <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                              Verified
                            </span>
                          )}
                        </div>
                        <div className="flex items-center space-x-2 text-sm text-gray-500">
                          <span>{review.location}</span>
                          <span>•</span>
                          <span>{review.date}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center space-x-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${
                              i < review.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                      <div className="text-sm text-gray-500 mt-1">{review.service}</div>
                    </div>
                  </div>
                  
                  <p className="text-gray-700 mb-4">"{review.comment}"</p>
                  
                  <div className="flex items-center space-x-4">
                    <button className="flex items-center space-x-1 text-gray-500 hover:text-gray-700">
                      <ThumbsUp className="h-4 w-4" />
                      <span className="text-sm">Helpful</span>
                    </button>
                    <button className="flex items-center space-x-1 text-gray-500 hover:text-gray-700">
                      <MessageCircle className="h-4 w-4" />
                      <span className="text-sm">Reply</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Review Form */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-xl p-6 sticky top-24">
              <h3 className="text-xl font-bold text-gray-900 mb-6">Leave a Review</h3>
              
              <form onSubmit={handleSubmitReview} className="space-y-4">
                {/* Name */}
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={newReview.name}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    required
                  />
                </div>

                {/* Service Type */}
                <div>
                  <label htmlFor="service" className="block text-sm font-medium text-gray-700 mb-2">
                    Service Used
                  </label>
                  <select
                    id="service"
                    name="service"
                    value={newReview.service}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  >
                    <option value="top-up">Diamond Top-Up</option>
                    <option value="account">Account Purchase</option>
                    <option value="custom">Custom Request</option>
                    <option value="support">Customer Support</option>
                  </select>
                </div>

                {/* Rating */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Rating *
                  </label>
                  <div className="flex items-center space-x-1">
                    {[1, 2, 3, 4, 5].map((rating) => (
                      <button
                        key={rating}
                        type="button"
                        onClick={() => setNewReview(prev => ({ ...prev, rating }))}
                        className="focus:outline-none"
                      >
                        <Star
                          className={`h-8 w-8 ${
                            rating <= newReview.rating
                              ? 'text-yellow-400 fill-current'
                              : 'text-gray-300'
                          } hover:text-yellow-400`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Comment */}
                <div>
                  <label htmlFor="comment" className="block text-sm font-medium text-gray-700 mb-2">
                    Your Review *
                  </label>
                  <textarea
                    id="comment"
                    name="comment"
                    value={newReview.comment}
                    onChange={handleInputChange}
                    rows={4}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    placeholder="Share your experience with us..."
                    required
                  />
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white py-3 px-6 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2"
                >
                  <Send className="h-5 w-5" />
                  <span>Submit Review</span>
                </button>
              </form>

              {/* Trust Indicators */}
              <div className="mt-8 pt-6 border-t border-gray-200">
                <h4 className="font-semibold text-gray-900 mb-4">Why customers trust us:</h4>
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-sm text-gray-600">1000+ happy customers</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-sm text-gray-600">4.9/5 average rating</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-sm text-gray-600">Fast & secure delivery</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-sm text-gray-600">24/7 customer support</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeedbackPage;