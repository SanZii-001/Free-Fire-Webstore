import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Users, Star, Shield, Filter, Search } from 'lucide-react';

const AccountShopPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRank, setSelectedRank] = useState('all');
  const [priceRange, setPriceRange] = useState('all');

  // Sample account data - in a real app, this would come from a database
  const accounts = [
    {
      id: 1,
      title: 'Diamond III Account - Rare Skins',
      rank: 'Diamond III',
      price: 2500,
      image: 'https://images.pexels.com/photos/3165335/pexels-photo-3165335.jpeg?auto=compress&cs=tinysrgb&w=400',
      features: ['5 Rare Character Skins', '15 Weapon Skins', '3 Pet Skins', 'Level 55'],
      uid: 'Hidden for security',
      region: 'Asia',
      status: 'available'
    },
    {
      id: 2,
      title: 'Heroic Tier Account - Elite Bundle',
      rank: 'Heroic',
      price: 5000,
      image: 'https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=400',
      features: ['10 Elite Bundles', '25 Weapon Skins', '5 Vehicle Skins', 'Level 62'],
      uid: 'Hidden for security',
      region: 'Asia',
      status: 'available'
    },
    {
      id: 3,
      title: 'Grand Master Account - Ultimate Collection',
      rank: 'Grand Master',
      price: 12000,
      image: 'https://images.pexels.com/photos/1293261/pexels-photo-1293261.jpeg?auto=compress&cs=tinysrgb&w=400',
      features: ['20+ Elite Bundles', '50+ Weapon Skins', '10+ Pet Skins', 'Level 75'],
      uid: 'Hidden for security',
      region: 'Asia',
      status: 'available'
    },
    {
      id: 4,
      title: 'Master Tier Account - Pro Setup',
      rank: 'Master',
      price: 8000,
      image: 'https://images.pexels.com/photos/1571086/pexels-photo-1571086.jpeg?auto=compress&cs=tinysrgb&w=400',
      features: ['15 Character Skins', '30 Weapon Skins', '8 Emotes', 'Level 68'],
      uid: 'Hidden for security',
      region: 'Asia',
      status: 'sold'
    },
    {
      id: 5,
      title: 'Elite Tier Account - Starter Bundle',
      rank: 'Elite',
      price: 3500,
      image: 'https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg?auto=compress&cs=tinysrgb&w=400',
      features: ['8 Character Skins', '18 Weapon Skins', '5 Emotes', 'Level 58'],
      uid: 'Hidden for security',
      region: 'Asia',
      status: 'available'
    },
    {
      id: 6,
      title: 'Platinum Account - Special Edition',
      rank: 'Platinum',
      price: 4200,
      image: 'https://images.pexels.com/photos/3694341/pexels-photo-3694341.jpeg?auto=compress&cs=tinysrgb&w=400',
      features: ['12 Character Skins', '22 Weapon Skins', '6 Pet Skins', 'Level 60'],
      uid: 'Hidden for security',
      region: 'Asia',
      status: 'available'
    }
  ];

  const filteredAccounts = accounts.filter(account => {
    const matchesSearch = account.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         account.rank.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRank = selectedRank === 'all' || account.rank.toLowerCase().includes(selectedRank.toLowerCase());
    const matchesPrice = priceRange === 'all' || 
                        (priceRange === 'low' && account.price < 3000) ||
                        (priceRange === 'mid' && account.price >= 3000 && account.price < 7000) ||
                        (priceRange === 'high' && account.price >= 7000);
    
    return matchesSearch && matchesRank && matchesPrice;
  });

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Premium Free Fire Accounts
          </h1>
          <p className="text-xl text-gray-600">
            Verified accounts with rare skins, high ranks, and exclusive items
          </p>
        </div>

        {/* Trust Indicators */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white rounded-lg p-6 text-center shadow-lg">
            <Shield className="h-12 w-12 text-green-500 mx-auto mb-3" />
            <h3 className="font-semibold text-gray-900 mb-2">Verified Accounts</h3>
            <p className="text-gray-600 text-sm">All accounts manually verified and tested</p>
          </div>
          <div className="bg-white rounded-lg p-6 text-center shadow-lg">
            <Users className="h-12 w-12 text-blue-500 mx-auto mb-3" />
            <h3 className="font-semibold text-gray-900 mb-2">Instant Transfer</h3>
            <p className="text-gray-600 text-sm">Account details delivered immediately</p>
          </div>
          <div className="bg-white rounded-lg p-6 text-center shadow-lg">
            <Star className="h-12 w-12 text-yellow-500 mx-auto mb-3" />
            <h3 className="font-semibold text-gray-900 mb-2">24/7 Support</h3>
            <p className="text-gray-600 text-sm">Help available anytime you need it</p>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search accounts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
            </div>

            {/* Rank Filter */}
            <div className="flex items-center space-x-2">
              <Filter className="h-5 w-5 text-gray-400" />
              <select
                value={selectedRank}
                onChange={(e) => setSelectedRank(e.target.value)}
                className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              >
                <option value="all">All Ranks</option>
                <option value="diamond">Diamond</option>
                <option value="elite">Elite</option>
                <option value="master">Master</option>
                <option value="heroic">Heroic</option>
                <option value="grand master">Grand Master</option>
              </select>
            </div>

            {/* Price Filter */}
            <div>
              <select
                value={priceRange}
                onChange={(e) => setPriceRange(e.target.value)}
                className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              >
                <option value="all">All Prices</option>
                <option value="low">Under Rs 3,000</option>
                <option value="mid">Rs 3,000 - 7,000</option>
                <option value="high">Above Rs 7,000</option>
              </select>
            </div>
          </div>
        </div>

        {/* Account Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredAccounts.map((account) => (
            <div key={account.id} className="bg-white rounded-xl shadow-xl overflow-hidden hover:shadow-2xl transition-shadow duration-300">
              {/* Account Image */}
              <div className="relative">
                <img
                  src={account.image}
                  alt={account.title}
                  className="w-full h-48 object-cover"
                />
                <div className="absolute top-4 right-4">
                  <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                    account.status === 'available' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {account.status === 'available' ? 'Available' : 'Sold Out'}
                  </span>
                </div>
                <div className="absolute bottom-4 left-4">
                  <span className="bg-black bg-opacity-70 text-white px-3 py-1 rounded-full text-sm font-semibold">
                    {account.rank}
                  </span>
                </div>
              </div>

              {/* Account Details */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3">{account.title}</h3>
                
                {/* Features */}
                <div className="space-y-2 mb-4">
                  {account.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm text-gray-600">{feature}</span>
                    </div>
                  ))}
                </div>

                {/* Price and Action */}
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-2xl font-bold text-red-600">Rs {account.price.toLocaleString()}</div>
                    <div className="text-sm text-gray-500">One-time payment</div>
                  </div>
                  
                  {account.status === 'available' ? (
                    <Link
                      to={`/account/${account.id}`}
                      className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105"
                    >
                      View Details
                    </Link>
                  ) : (
                    <button
                      disabled
                      className="bg-gray-400 text-white px-6 py-3 rounded-lg font-semibold cursor-not-allowed"
                    >
                      Sold Out
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* No Results */}
        {filteredAccounts.length === 0 && (
          <div className="text-center py-12">
            <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No accounts found</h3>
            <p className="text-gray-600">Try adjusting your search filters</p>
          </div>
        )}

        {/* Custom Request CTA */}
        <div className="mt-16 bg-gradient-to-r from-red-500 to-yellow-500 rounded-xl p-8 text-center text-white">
          <h3 className="text-2xl font-bold mb-4">Looking for Something Specific?</h3>
          <p className="text-lg mb-6">
            Can't find the perfect account? Let us know what you're looking for and we'll help you find it!
          </p>
          <Link
            to="/custom-request"
            className="bg-white text-red-600 hover:bg-gray-100 px-8 py-3 rounded-lg font-semibold transition-colors inline-flex items-center space-x-2"
          >
            <Users className="h-5 w-5" />
            <span>Request Custom Account</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default AccountShopPage;