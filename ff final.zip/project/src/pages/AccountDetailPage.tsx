import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Shield, Star, MessageCircle, CheckCircle, AlertCircle } from 'lucide-react';
import CheckoutModal from '../components/CheckoutModal';

const AccountDetailPage = () => {
  const { id } = useParams();
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('esewa');
  const [showCheckout, setShowCheckout] = useState(false);

  // Sample account data - in a real app, this would be fetched based on ID
  const account = {
    id: 1,
    title: 'Diamond III Account - Rare Skins Collection',
    rank: 'Diamond III',
    price: 2500,
    images: [
      'https://images.pexels.com/photos/3165335/pexels-photo-3165335.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1293261/pexels-photo-1293261.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    description: 'This premium Free Fire account comes with an extensive collection of rare character skins, weapon skins, and exclusive items. Perfect for players who want to stand out in the battleground with style.',
    features: [
      '5 Rare Character Skins (including limited edition)',
      '15 Premium Weapon Skins with special effects',
      '3 Exclusive Pet Skins with unique abilities',
      'Level 55 with high XP and achievements',
      '12 Elite Emotes and victory dances',
      '8 Vehicle Skins for cars and bikes',
      '50+ Name change cards and room cards',
      'Diamond Pass benefits unlocked'
    ],
    specs: {
      uid: '••••••••45 (Hidden for security)',
      level: 55,
      rank: 'Diamond III',
      region: 'Asia Server',
      totalMatches: '1,250+',
      winRate: '78%',
      kd: '2.4',
      badges: 15
    },
    status: 'available',
    verification: {
      verified: true,
      lastChecked: '2024-01-15',
      screenshots: true,
      videoProof: true
    }
  };

  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const handlePurchase = () => {
    setShowCheckout(true);
  };

  const handleWhatsAppContact = () => {
    window.open(`https://wa.me/9779769222045?text=Hi! I'm interested in the ${account.title} (ID: ${account.id}). Can you provide more details?`, '_blank');
  };

  const getCheckoutItem = () => ({
    type: 'account' as const,
    title: account.title,
    price: account.price,
    details: `${account.rank} Free Fire account with ${account.features.length} premium features`
  });

  if (!account) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Account not found</h2>
          <Link to="/accounts" className="text-red-600 hover:text-red-700">
            ← Back to accounts
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <div className="mb-8">
          <Link
            to="/accounts"
            className="inline-flex items-center space-x-2 text-red-600 hover:text-red-700 font-medium"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>Back to Accounts</span>
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Images and Details */}
          <div className="lg:col-span-2">
            {/* Image Gallery */}
            <div className="bg-white rounded-xl shadow-xl overflow-hidden mb-8">
              <div className="relative">
                <img
                  src={account.images[currentImageIndex]}
                  alt={account.title}
                  className="w-full h-96 object-cover"
                />
                <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                  {account.images.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentImageIndex(index)}
                      className={`w-3 h-3 rounded-full ${
                        index === currentImageIndex ? 'bg-white' : 'bg-white bg-opacity-50'
                      }`}
                    />
                  ))}
                </div>
                {account.verification.verified && (
                  <div className="absolute top-4 right-4">
                    <div className="bg-green-500 text-white px-3 py-1 rounded-full flex items-center space-x-1">
                      <Shield className="h-4 w-4" />
                      <span className="text-sm font-semibold">Verified</span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Account Details */}
            <div className="bg-white rounded-xl shadow-xl p-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-4">{account.title}</h1>
              <p className="text-gray-600 mb-6">{account.description}</p>

              {/* Features */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">What's Included</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {account.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Account Specifications */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Account Specifications</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.entries(account.specs).map(([key, value]) => (
                    <div key={key} className="bg-gray-50 rounded-lg p-4">
                      <div className="text-sm text-gray-500 capitalize">
                        {key.replace(/([A-Z])/g, ' $1').trim()}
                      </div>
                      <div className="font-semibold text-gray-900">{value}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Verification Info */}
              <div className="bg-green-50 rounded-lg p-6">
                <div className="flex items-center space-x-2 mb-3">
                  <Shield className="h-6 w-6 text-green-600" />
                  <h3 className="text-lg font-semibold text-green-900">Verification Status</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span className="text-green-800">Account Verified</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span className="text-green-800">Screenshots Provided</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span className="text-green-800">Video Proof Available</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span className="text-green-800">Last Checked: {account.verification.lastChecked}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Purchase Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-xl p-6 sticky top-24">
              <div className="text-center mb-6">
                <div className="text-3xl font-bold text-red-600 mb-2">
                  Rs {account.price.toLocaleString()}
                </div>
                <div className="text-sm text-gray-500">One-time payment</div>
                <div className="flex items-center justify-center space-x-1 mt-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                  ))}
                  <span className="text-sm text-gray-600 ml-2">(4.9/5 rating)</span>
                </div>
              </div>

              {/* Status */}
              <div className="mb-6">
                <div className={`w-full py-3 px-4 rounded-lg text-center font-semibold ${
                  account.status === 'available' 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-red-100 text-red-800'
                }`}>
                  {account.status === 'available' ? '✅ Available Now' : '❌ Sold Out'}
                </div>
              </div>

              {/* Purchase Button */}
              {account.status === 'available' ? (
                <button
                  onClick={handlePurchase}
                  className="w-full bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white py-4 px-6 rounded-lg font-semibold text-lg transition-all duration-300 transform hover:scale-105 mb-4"
                >
                  Buy Now - Rs {account.price.toLocaleString()}
                </button>
              ) : (
                <button
                  disabled
                  className="w-full bg-gray-400 text-white py-4 px-6 rounded-lg font-semibold text-lg cursor-not-allowed mb-4"
                >
                  Account Sold Out
                </button>
              )}

              {/* WhatsApp Contact */}
              <button
                onClick={handleWhatsAppContact}
                className="w-full bg-green-600 hover:bg-green-700 text-white py-3 px-6 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2"
              >
                <MessageCircle className="h-5 w-5" />
                <span>Contact on WhatsApp</span>
              </button>

              {/* Important Notes */}
              <div className="mt-6 bg-yellow-50 rounded-lg p-4">
                <div className="flex items-start space-x-2">
                  <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-semibold mb-2">Important Notes:</p>
                    <ul className="space-y-1 text-sm">
                      <li>• Account details sent instantly after payment</li>
                      <li>• Email verification required for security</li>
                      <li>• 24-hour support included</li>
                      <li>• No refunds after account transfer</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Security Features */}
              <div className="mt-4 space-y-2">
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <Shield className="h-4 w-4 text-green-500" />
                  <span>Secure payment processing</span>
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Instant account delivery</span>
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <MessageCircle className="h-4 w-4 text-green-500" />
                  <span>24/7 customer support</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Checkout Modal */}
      {showCheckout && (
        <CheckoutModal
          isOpen={showCheckout}
          onClose={() => setShowCheckout(false)}
          item={getCheckoutItem()}
        />
      )}
    </div>
  );
};

export default AccountDetailPage;