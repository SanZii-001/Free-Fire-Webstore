import React, { useState } from 'react';
import { Phone, Mail, MapPin, MessageCircle, Clock, Send, Facebook, Instagram } from 'lucide-react';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
    urgency: 'normal'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      alert('Please fill in all required fields');
      return;
    }
    
    // In a real app, this would be sent to a backend
    alert('Thank you for contacting us! We will get back to you within 24 hours.');
    setFormData({ name: '', email: '', phone: '', subject: '', message: '', urgency: 'normal' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const contactMethods = [
    {
      icon: Phone,
      title: 'Phone Support',
      description: 'Call us for immediate assistance',
      contact: '+977 9769222045',
      action: 'tel:+9779769222045',
      availability: '24/7 Available',
      color: 'text-green-600',
      bgColor: 'bg-green-100'
    },
    {
      icon: MessageCircle,
      title: 'WhatsApp Chat',
      description: 'Quick support via WhatsApp',
      contact: '+977 9769222045',
      action: 'https://wa.me/9779769222045?text=Hi! I need help with Free Fire services.',
      availability: 'Instant Response',
      color: 'text-green-600',
      bgColor: 'bg-green-100'
    },
    {
      icon: Mail,
      title: 'Email Support',
      description: 'Send us detailed inquiries',
      contact: 'support@ffstorenepal.com',
      action: 'mailto:support@ffstorenepal.com',
      availability: 'Response within 6 hours',
      color: 'text-blue-600',
      bgColor: 'bg-blue-100'
    },
    {
      icon: Facebook,
      title: 'Facebook Messenger',
      description: 'Chat with us on Facebook',
      contact: 'FF Store Nepal',
      action: '#',
      availability: 'Active during business hours',
      color: 'text-blue-600',
      bgColor: 'bg-blue-100'
    }
  ];

  const businessHours = [
    { day: 'Monday - Friday', hours: '9:00 AM - 10:00 PM' },
    { day: 'Saturday - Sunday', hours: '10:00 AM - 8:00 PM' },
    { day: 'Emergency Support', hours: '24/7 Available' }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Contact FF Store Nepal
          </h1>
          <p className="text-xl text-gray-600">
            Get in touch with our support team for any questions or assistance
          </p>
        </div>

        {/* Quick Contact Methods */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {contactMethods.map((method, index) => (
            <a
              key={index}
              href={method.action}
              target={method.action.startsWith('http') ? '_blank' : undefined}
              rel={method.action.startsWith('http') ? 'noopener noreferrer' : undefined}
              className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300 text-center group"
            >
              <div className={`${method.bgColor} w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform`}>
                <method.icon className={`h-8 w-8 ${method.color}`} />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">{method.title}</h3>
              <p className="text-gray-600 text-sm mb-2">{method.description}</p>
              <p className="font-medium text-gray-900 mb-1">{method.contact}</p>
              <p className="text-xs text-green-600 font-medium">{method.availability}</p>
            </a>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Contact Form */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-xl p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Send us a Message</h2>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Name */}
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      required
                    />
                  </div>

                  {/* Phone */}
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Email */}
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      required
                    />
                  </div>

                  {/* Urgency */}
                  <div>
                    <label htmlFor="urgency" className="block text-sm font-medium text-gray-700 mb-2">
                      Priority Level
                    </label>
                    <select
                      id="urgency"
                      name="urgency"
                      value={formData.urgency}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    >
                      <option value="normal">Normal</option>
                      <option value="urgent">Urgent</option>
                      <option value="emergency">Emergency</option>
                    </select>
                  </div>
                </div>

                {/* Subject */}
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-2">
                    Subject
                  </label>
                  <input
                    type="text"
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    placeholder="Brief description of your inquiry"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  />
                </div>

                {/* Message */}
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                    Message *
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={6}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    placeholder="Please describe your question or issue in detail..."
                    required
                  />
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white py-4 px-8 rounded-lg font-semibold text-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2"
                >
                  <Send className="h-6 w-6" />
                  <span>Send Message</span>
                </button>
              </form>
            </div>
          </div>

          {/* Contact Information */}
          <div className="lg:col-span-1 space-y-8">
            {/* Business Hours */}
            <div className="bg-white rounded-xl shadow-xl p-6">
              <div className="flex items-center space-x-2 mb-4">
                <Clock className="h-6 w-6 text-blue-600" />
                <h3 className="text-xl font-bold text-gray-900">Business Hours</h3>
              </div>
              <div className="space-y-3">
                {businessHours.map((schedule, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <span className="text-gray-600">{schedule.day}</span>
                    <span className="font-medium text-gray-900">{schedule.hours}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Office Location */}
            <div className="bg-white rounded-xl shadow-xl p-6">
              <div className="flex items-center space-x-2 mb-4">
                <MapPin className="h-6 w-6 text-red-600" />
                <h3 className="text-xl font-bold text-gray-900">Our Location</h3>
              </div>
              <div className="space-y-2">
                <p className="text-gray-600">FF Store Nepal</p>
                <p className="text-gray-600">Kathmandu, Nepal</p>
                <p className="text-gray-600">Digital Gaming Store</p>
              </div>
              <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600">
                  <strong>Note:</strong> We operate as a digital store. All services are provided online 
                  for your convenience and safety.
                </p>
              </div>
            </div>

            {/* Quick Response Promise */}
            <div className="bg-gradient-to-r from-red-500 to-yellow-500 rounded-xl p-6 text-white">
              <h3 className="text-xl font-bold mb-4">Quick Response Promise</h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <MessageCircle className="h-5 w-5" />
                  <span>WhatsApp: Instant response</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Phone className="h-5 w-5" />
                  <span>Phone: Available 24/7</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Mail className="h-5 w-5" />
                  <span>Email: Within 6 hours</span>
                </div>
              </div>
            </div>

            {/* Emergency Support */}
            <div className="bg-yellow-50 rounded-xl p-6 border border-yellow-200">
              <h3 className="text-lg font-bold text-yellow-800 mb-3">Emergency Support</h3>
              <p className="text-yellow-700 text-sm mb-4">
                For urgent issues like payment problems or account access issues, 
                contact us immediately via WhatsApp or phone.
              </p>
              <a
                href="https://wa.me/9779769222045?text=URGENT: I need immediate help with my Free Fire order!"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-yellow-600 hover:bg-yellow-700 text-white py-3 px-6 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2"
              >
                <MessageCircle className="h-5 w-5" />
                <span>Emergency WhatsApp</span>
              </a>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mt-16 bg-white rounded-xl shadow-xl p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Frequently Asked Questions</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">How fast is diamond delivery?</h4>
              <p className="text-gray-600 text-sm">Most diamond top-ups are completed within 5-15 minutes after payment confirmation.</p>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">What payment methods do you accept?</h4>
              <p className="text-gray-600 text-sm">We accept eSewa, Khalti, IME Pay, and other major Nepali digital wallets.</p>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Are the accounts safe to buy?</h4>
              <p className="text-gray-600 text-sm">Yes, all accounts are manually verified and come with our guarantee for secure transfer.</p>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Do you offer refunds?</h4>
              <p className="text-gray-600 text-sm">Refunds are available if diamonds are not delivered within 24 hours or if accounts don't match descriptions.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;