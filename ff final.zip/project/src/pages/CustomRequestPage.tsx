import React, { useState } from 'react';
import { Send, MessageCircle, Clock, CheckCircle } from 'lucide-react';

const CustomRequestPage = () => {
  const [formData, setFormData] = useState({
    uid: '',
    diamonds: '',
    notes: '',
    contact: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.uid || !formData.diamonds || !formData.contact) {
      alert('Please fill in all required fields');
      return;
    }
    
    // In a real app, this would be stored in database
    alert('Custom request submitted! We will contact you within 30 minutes with pricing and details.');
    setFormData({ uid: '', diamonds: '', notes: '', contact: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Custom Diamond Request
          </h1>
          <p className="text-xl text-gray-600">
            Need a specific amount of diamonds? Request a custom quote!
          </p>
        </div>

        {/* Process Steps */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white rounded-lg p-6 text-center shadow-lg">
            <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Send className="h-8 w-8 text-blue-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">1. Submit Request</h3>
            <p className="text-gray-600 text-sm">Fill out the form with your requirements</p>
          </div>
          <div className="bg-white rounded-lg p-6 text-center shadow-lg">
            <div className="bg-yellow-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageCircle className="h-8 w-8 text-yellow-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">2. Get Quote</h3>
            <p className="text-gray-600 text-sm">Receive custom pricing within 30 minutes</p>
          </div>
          <div className="bg-white rounded-lg p-6 text-center shadow-lg">
            <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">3. Complete Order</h3>
            <p className="text-gray-600 text-sm">Pay and receive your diamonds instantly</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Request Form */}
          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-xl p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Request Details</h2>
              
              {/* UID Input */}
              <div className="mb-6">
                <label htmlFor="uid" className="block text-lg font-semibold text-gray-900 mb-3">
                  Free Fire UID *
                </label>
                <input
                  type="text"
                  id="uid"
                  name="uid"
                  value={formData.uid}
                  onChange={handleChange}
                  placeholder="Enter your Free Fire UID"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent text-lg"
                  required
                />
                <p className="text-sm text-gray-500 mt-2">
                  Your Free Fire User ID for diamond delivery
                </p>
              </div>

              {/* Diamond Amount */}
              <div className="mb-6">
                <label htmlFor="diamonds" className="block text-lg font-semibold text-gray-900 mb-3">
                  How many diamonds do you want? *
                </label>
                <input
                  type="number"
                  id="diamonds"
                  name="diamonds"
                  value={formData.diamonds}
                  onChange={handleChange}
                  placeholder="e.g., 2500"
                  min="1"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent text-lg"
                  required
                />
                <p className="text-sm text-gray-500 mt-2">
                  Minimum order: 100 diamonds
                </p>
              </div>

              {/* Contact Info */}
              <div className="mb-6">
                <label htmlFor="contact" className="block text-lg font-semibold text-gray-900 mb-3">
                  Contact Number *
                </label>
                <input
                  type="tel"
                  id="contact"
                  name="contact"
                  value={formData.contact}
                  onChange={handleChange}
                  placeholder="98xxxxxxxx"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent text-lg"
                  required
                />
                <p className="text-sm text-gray-500 mt-2">
                  We'll contact you on this number for confirmation
                </p>
              </div>

              {/* Additional Notes */}
              <div className="mb-8">
                <label htmlFor="notes" className="block text-lg font-semibold text-gray-900 mb-3">
                  Additional Notes (Optional)
                </label>
                <textarea
                  id="notes"
                  name="notes"
                  value={formData.notes}
                  onChange={handleChange}
                  rows={4}
                  placeholder="Any special requirements or preferred payment method..."
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white py-4 px-8 rounded-lg font-semibold text-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2"
              >
                <Send className="h-6 w-6" />
                <span>Submit Custom Request</span>
              </button>
            </form>
          </div>

          {/* Info Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-xl p-6 sticky top-24">
              <h3 className="text-xl font-bold text-gray-900 mb-6">Why Custom Requests?</h3>
              
              <div className="space-y-4 mb-6">
                <div className="flex items-start space-x-3">
                  <div className="bg-green-100 rounded-full p-2 mt-1">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Better Pricing</h4>
                    <p className="text-sm text-gray-600">Get discounted rates for bulk orders</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="bg-blue-100 rounded-full p-2 mt-1">
                    <Clock className="h-4 w-4 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Quick Response</h4>
                    <p className="text-sm text-gray-600">Get quotes within 30 minutes</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="bg-purple-100 rounded-full p-2 mt-1">
                    <MessageCircle className="h-4 w-4 text-purple-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Personal Service</h4>
                    <p className="text-sm text-gray-600">Direct communication with our team</p>
                  </div>
                </div>
              </div>

              <div className="bg-yellow-50 rounded-lg p-4 mb-6">
                <h4 className="font-semibold text-yellow-800 mb-2">💡 Pro Tip</h4>
                <p className="text-sm text-yellow-700">
                  Orders above 5000 diamonds get special bulk pricing! 
                  Mention "BULK5K" in your notes for faster processing.
                </p>
              </div>
              
              <div className="text-center">
                <div className="flex items-center justify-center space-x-2 text-green-600 mb-2">
                  <Clock className="h-5 w-5" />
                  <span className="font-semibold">Response Time: 30 Minutes</span>
                </div>
                <p className="text-sm text-gray-500 mb-4">
                  Our team is online 24/7 to help you
                </p>
                
                <a
                  href="https://wa.me/9779769222045?text=Hi! I want to make a custom diamond request."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-green-600 hover:bg-green-700 text-white py-3 px-6 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2"
                >
                  <MessageCircle className="h-5 w-5" />
                  <span>Chat on WhatsApp</span>
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Sample Bulk Pricing */}
        <div className="mt-12 bg-white rounded-xl shadow-xl p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Sample Bulk Pricing</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gray-50 rounded-lg p-6 text-center">
              <h4 className="text-lg font-semibold text-gray-900 mb-2">2500 Diamonds</h4>
              <p className="text-2xl font-bold text-red-600 mb-2">Rs 2,800</p>
              <p className="text-sm text-gray-600">Save Rs 200 vs regular price</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-6 text-center">
              <h4 className="text-lg font-semibold text-gray-900 mb-2">5000 Diamonds</h4>
              <p className="text-2xl font-bold text-red-600 mb-2">Rs 5,400</p>
              <p className="text-sm text-gray-600">Save Rs 600 vs regular price</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-6 text-center">
              <h4 className="text-lg font-semibold text-gray-900 mb-2">10000+ Diamonds</h4>
              <p className="text-2xl font-bold text-red-600 mb-2">Best Price</p>
              <p className="text-sm text-gray-600">Contact for special rates</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomRequestPage;