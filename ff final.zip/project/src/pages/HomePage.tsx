import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Diamond, Users, Star, Shield, Clock, Award, ChevronRight, Zap, Heart, Trophy, Sparkles, Flame, CheckCircle, ArrowRight } from 'lucide-react';
import TrustBadges from '../components/TrustBadges';
import SecurityBanner from '../components/SecurityBanner';
import TestimonialCarousel from '../components/TestimonialCarousel';

const HomePage = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const features = [
    { 
      icon: Shield, 
      title: 'Bank-Level Security', 
      desc: 'SSL encrypted payments with fraud protection', 
      color: 'from-green-500 to-green-600',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200'
    },
    { 
      icon: Zap, 
      title: 'Lightning Delivery', 
      desc: 'Automated system delivers in 2-5 minutes', 
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200'
    },
    { 
      icon: Award, 
      title: 'Licensed Business', 
      desc: 'Registered & verified gaming store', 
      color: 'from-purple-500 to-purple-600',
      bgColor: 'bg-purple-50',
      borderColor: 'border-purple-200'
    },
    { 
      icon: Star, 
      title: '4.9★ Excellence', 
      desc: 'Rated by 10,000+ satisfied customers', 
      color: 'from-yellow-500 to-yellow-600',
      bgColor: 'bg-yellow-50',
      borderColor: 'border-yellow-200'
    },
  ];

  const stats = [
    { number: '10,000+', label: 'Happy Customers', icon: Heart, color: 'text-red-500' },
    { number: '500K+', label: 'Diamonds Delivered', icon: Diamond, color: 'text-blue-500' },
    { number: '4.9/5', label: 'Customer Rating', icon: Star, color: 'text-yellow-500' },
    { number: '2-5min', label: 'Average Delivery', icon: Clock, color: 'text-green-500' },
  ];

  const guarantees = [
    {
      icon: Shield,
      title: 'Money Back Guarantee',
      description: '100% refund if diamonds not delivered within 24 hours'
    },
    {
      icon: CheckCircle,
      title: 'Instant Delivery Promise',
      description: 'Automated delivery system ensures 2-5 minute delivery'
    },
    {
      icon: Award,
      title: 'Verified Accounts Only',
      description: 'All accounts manually verified and tested before sale'
    }
  ];

  return (
    <div className="min-h-screen overflow-hidden">
      {/* Security Banner */}
      <SecurityBanner />

      {/* Hero Section */}
      <section className="relative min-h-screen bg-gradient-to-br from-black via-red-900 to-black text-white flex items-center overflow-hidden">
        {/* Enhanced Animated Background */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-20 left-10 w-32 h-32 bg-red-500 rounded-full animate-pulse"></div>
          <div className="absolute top-40 right-20 w-24 h-24 bg-yellow-500 rounded-full animate-bounce"></div>
          <div className="absolute bottom-32 left-1/4 w-16 h-16 bg-blue-500 rounded-full animate-ping"></div>
          <div className="absolute bottom-20 right-1/3 w-20 h-20 bg-green-500 rounded-full animate-pulse"></div>
          <div className="absolute top-1/2 left-1/2 w-40 h-40 bg-purple-500 rounded-full animate-spin opacity-10"></div>
          
          {/* Grid pattern overlay */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-5 transform -skew-x-12 animate-pulse"></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className={`text-center transition-all duration-1500 ${
            isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'
          }`}>
            {/* Trust Indicators */}
            <div className="flex items-center justify-center space-x-6 mb-8">
              <div className="flex items-center space-x-2 bg-green-600/20 backdrop-blur-sm px-4 py-2 rounded-full border border-green-500/30">
                <Shield className="h-5 w-5 text-green-400" />
                <span className="text-green-400 font-semibold text-sm">SSL Secured</span>
              </div>
              <div className="flex items-center space-x-2 bg-blue-600/20 backdrop-blur-sm px-4 py-2 rounded-full border border-blue-500/30">
                <Award className="h-5 w-5 text-blue-400" />
                <span className="text-blue-400 font-semibold text-sm">Licensed Business</span>
              </div>
              <div className="flex items-center space-x-2 bg-yellow-600/20 backdrop-blur-sm px-4 py-2 rounded-full border border-yellow-500/30">
                <Star className="h-5 w-5 text-yellow-400" />
                <span className="text-yellow-400 font-semibold text-sm">4.9★ Rated</span>
              </div>
            </div>

            <div className="flex items-center justify-center space-x-3 mb-8">
              <div className="bg-gradient-to-r from-red-500 to-yellow-500 p-3 rounded-full animate-bounce shadow-2xl">
                <Flame className="h-8 w-8 text-white" />
              </div>
              <div className="bg-gradient-to-r from-yellow-500 to-red-500 p-3 rounded-full animate-pulse shadow-2xl">
                <Trophy className="h-8 w-8 text-white" />
              </div>
              <div className="bg-gradient-to-r from-red-500 to-yellow-500 p-3 rounded-full animate-bounce shadow-2xl">
                <Sparkles className="h-8 w-8 text-white" />
              </div>
            </div>

            <h1 className="text-4xl md:text-7xl font-bold mb-8 leading-tight">
              <span className="block mb-4">Nepal's #1 Trusted</span>
              <span className="bg-gradient-to-r from-yellow-400 via-red-500 to-yellow-400 bg-clip-text text-transparent animate-pulse">
                Free Fire Store
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-4xl mx-auto leading-relaxed">
              Get instant diamond top-ups and verified Free Fire accounts with 
              <span className="text-yellow-400 font-semibold"> bank-level security</span> and 
              <span className="text-green-400 font-semibold"> 2-5 minute delivery!</span>
            </p>

            {/* Social Proof */}
            <div className="flex items-center justify-center space-x-8 mb-12 text-sm">
              <div className="flex items-center space-x-2">
                <Users className="h-5 w-5 text-blue-400" />
                <span className="text-gray-300">10,000+ Customers</span>
              </div>
              <div className="flex items-center space-x-2">
                <Diamond className="h-5 w-5 text-yellow-400" />
                <span className="text-gray-300">500K+ Diamonds Delivered</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-green-400" />
                <span className="text-gray-300">2-5 Min Delivery</span>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-16">
              <Link
                to="/top-up"
                className="group bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white px-12 py-6 rounded-2xl font-bold text-xl transition-all duration-500 transform hover:scale-110 hover:shadow-2xl hover:shadow-red-500/50 flex items-center space-x-3 border-2 border-red-400/50"
              >
                <Diamond className="h-7 w-7 group-hover:animate-spin" />
                <span>Buy Diamonds Now</span>
                <ArrowRight className="h-6 w-6 group-hover:translate-x-2 transition-transform" />
              </Link>
              <Link
                to="/accounts"
                className="group bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black px-12 py-6 rounded-2xl font-bold text-xl transition-all duration-500 transform hover:scale-110 hover:shadow-2xl hover:shadow-yellow-500/50 flex items-center space-x-3 border-2 border-yellow-400/50"
              >
                <Users className="h-7 w-7 group-hover:animate-bounce" />
                <span>Premium Accounts</span>
                <ArrowRight className="h-6 w-6 group-hover:translate-x-2 transition-transform" />
              </Link>
            </div>

            {/* Payment Methods */}
            <div className="flex flex-col items-center space-y-4">
              <span className="text-gray-400 text-lg font-medium">Secure payments powered by:</span>
              <div className="flex flex-wrap justify-center gap-6">
                <div className="bg-gradient-to-r from-purple-600 to-purple-700 px-8 py-4 rounded-xl font-bold shadow-2xl hover:shadow-purple-500/50 transition-all duration-300 hover:scale-110 border border-purple-400/30">
                  eSewa
                </div>
                <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-8 py-4 rounded-xl font-bold shadow-2xl hover:shadow-blue-500/50 transition-all duration-300 hover:scale-110 border border-blue-400/30">
                  Khalti
                </div>
                <div className="bg-gradient-to-r from-green-600 to-green-700 px-8 py-4 rounded-xl font-bold shadow-2xl hover:shadow-green-500/50 transition-all duration-300 hover:scale-110 border border-green-400/30">
                  IME Pay
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <div className="w-8 h-12 border-2 border-white rounded-full flex justify-center p-2">
            <div className="w-1 h-4 bg-white rounded-full animate-pulse"></div>
          </div>
          <p className="text-white text-xs mt-2 text-center">Scroll to explore</p>
        </div>
      </section>

      {/* Enhanced Stats Section */}
      <section className="py-20 bg-gradient-to-r from-gray-900 via-black to-gray-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-red-500/10 via-transparent to-yellow-500/10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">Trusted by Thousands</h2>
            <p className="text-gray-400">Real numbers from real customers</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center group">
                <div className="bg-gradient-to-r from-gray-800 to-gray-900 border border-gray-700 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300 shadow-2xl">
                  <stat.icon className={`h-8 w-8 ${stat.color}`} />
                </div>
                <div className="text-4xl font-bold text-white mb-2">{stat.number}</div>
                <div className="text-gray-400 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced Features Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-white relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-red-50/50 to-yellow-50/50"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Why 10,000+ Gamers Choose Us
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Experience the difference with Nepal's most trusted and secure Free Fire store
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {features.map((feature, index) => (
              <div key={index} className={`group text-center p-8 rounded-2xl bg-white shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-4 ${feature.borderColor} border-2`}>
                <div className={`bg-gradient-to-r ${feature.color} w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 shadow-lg`}>
                  <feature.icon className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>

          {/* Trust Badges */}
          <TrustBadges />
        </div>
      </section>

      {/* Guarantees Section */}
      <section className="py-20 bg-gradient-to-r from-green-600 to-green-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Our Guarantees to You</h2>
            <p className="text-xl text-green-100">Your satisfaction and security are our top priorities</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {guarantees.map((guarantee, index) => (
              <div key={index} className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 text-center border border-white/20 hover:bg-white/20 transition-all duration-300">
                <div className="bg-white/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <guarantee.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold mb-4">{guarantee.title}</h3>
                <p className="text-green-100 leading-relaxed">{guarantee.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced Services Preview */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Premium Services</h2>
            <p className="text-xl text-gray-600">Choose from our most popular gaming solutions</p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Diamond Top-Up */}
            <div className="bg-white rounded-3xl p-8 shadow-2xl hover:shadow-3xl transition-all duration-500 hover:-translate-y-2 border-2 border-blue-100 group">
              <div className="flex items-center space-x-4 mb-8">
                <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-4 rounded-2xl group-hover:scale-110 transition-transform duration-300 shadow-lg">
                  <Diamond className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h3 className="text-3xl font-bold text-gray-900">Diamond Top-Up</h3>
                  <p className="text-blue-600 font-semibold">Instant • Secure • Guaranteed</p>
                </div>
              </div>
              <p className="text-gray-600 mb-8 text-lg leading-relaxed">
                Lightning-fast Free Fire diamond delivery with automated system. Choose from 16 different packages with competitive pricing and instant delivery.
              </p>
              <div className="space-y-4 mb-8">
                {[
                  { diamonds: '115 Diamonds', price: 'Rs 95', savings: null },
                  { diamonds: '480 Diamonds', price: 'Rs 400', savings: 'Most Popular', popular: true },
                  { diamonds: '1090 Diamonds', price: 'Rs 920', savings: 'Best Value' },
                ].map((pkg, index) => (
                  <div key={index} className={`flex justify-between items-center p-4 rounded-xl transition-all duration-300 ${
                    pkg.popular 
                      ? 'bg-gradient-to-r from-blue-50 to-blue-100 border-2 border-blue-200 shadow-lg' 
                      : 'bg-gray-50 hover:bg-gray-100 border border-gray-200'
                  }`}>
                    <div className="flex items-center space-x-3">
                      <Diamond className="h-5 w-5 text-blue-500" />
                      <span className="font-semibold">{pkg.diamonds}</span>
                      {pkg.savings && (
                        <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                          pkg.popular ? 'bg-blue-500 text-white' : 'bg-green-500 text-white'
                        }`}>
                          {pkg.savings}
                        </span>
                      )}
                    </div>
                    <span className="font-bold text-blue-600 text-lg">{pkg.price}</span>
                  </div>
                ))}
              </div>
              <Link
                to="/top-up"
                className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white py-4 px-8 rounded-xl font-bold text-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-3 shadow-lg hover:shadow-blue-500/25"
              >
                <span>Start Top-Up</span>
                <ArrowRight className="h-6 w-6" />
              </Link>
            </div>

            {/* Account Store */}
            <div className="bg-white rounded-3xl p-8 shadow-2xl hover:shadow-3xl transition-all duration-500 hover:-translate-y-2 border-2 border-green-100 group">
              <div className="flex items-center space-x-4 mb-8">
                <div className="bg-gradient-to-r from-green-500 to-green-600 p-4 rounded-2xl group-hover:scale-110 transition-transform duration-300 shadow-lg">
                  <Users className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h3 className="text-3xl font-bold text-gray-900">Premium Accounts</h3>
                  <p className="text-green-600 font-semibold">Verified • Authentic • Guaranteed</p>
                </div>
              </div>
              <p className="text-gray-600 mb-8 text-lg leading-relaxed">
                Handpicked verified Free Fire accounts with rare skins, high ranks, and exclusive items. All accounts are manually tested and come with lifetime support.
              </p>
              <div className="space-y-4 mb-8">
                {[
                  { tier: 'Diamond Tier Account', price: 'Rs 2,500', features: '5+ Rare Skins' },
                  { tier: 'Heroic Tier Account', price: 'Rs 5,000', features: '15+ Elite Bundles', popular: true },
                  { tier: 'Grand Master Account', price: 'Rs 12,000', features: '25+ Premium Items' },
                ].map((account, index) => (
                  <div key={index} className={`flex justify-between items-center p-4 rounded-xl transition-all duration-300 ${
                    account.popular 
                      ? 'bg-gradient-to-r from-green-50 to-green-100 border-2 border-green-200 shadow-lg' 
                      : 'bg-gray-50 hover:bg-gray-100 border border-gray-200'
                  }`}>
                    <div className="flex items-center space-x-3">
                      <Users className="h-5 w-5 text-green-500" />
                      <div>
                        <span className="font-semibold block">{account.tier}</span>
                        <span className="text-sm text-gray-600">{account.features}</span>
                      </div>
                      {account.popular && (
                        <span className="bg-green-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                          POPULAR
                        </span>
                      )}
                    </div>
                    <span className="font-bold text-green-600 text-lg">{account.price}</span>
                  </div>
                ))}
              </div>
              <Link
                to="/accounts"
                className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white py-4 px-8 rounded-xl font-bold text-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-3 shadow-lg hover:shadow-green-500/25"
              >
                <span>Browse Accounts</span>
                <ArrowRight className="h-6 w-6" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Reviews Section */}
      <section className="py-20 bg-gradient-to-br from-gray-900 to-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              What Our Customers Say
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Real reviews from verified customers who trust NS Store Nepal
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto mb-12">
            <TestimonialCarousel />
          </div>
          
          <div className="text-center">
            <Link
              to="/feedback"
              className="inline-flex items-center space-x-3 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-red-500/25"
            >
              <Star className="h-6 w-6" />
              <span>Read All Reviews</span>
              <ArrowRight className="h-6 w-6" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;